# Checking the 669/800 critical-line bound with the published RH theorem

The Lean theorems `CriticalLine669.dyadic_669` and `CriticalLine669.cumulative_669` give an asymptotic lower bound of 669/800 (83.625%) for distinct zeros on the critical line, with total zeros counted with multiplicity. They cover the intervals (T, 2T] and (0, T], respectively. For every positive ε the bound holds with coefficient 669/800 − ε for all sufficiently large T.

Both declarations compile in Lean 4.33.1. Their only axioms are `propext`, `Classical.choice`, and `Quot.sound`. Their types have no RH hypothesis. The code applies the published Lean proof `riemannHypothesis : RiemannHypothesis`. The proof of `offLineLoss` gives exactly zero distinct off-line zeros in each counting window.

## Mathematical provenance

Alpöge and Furman supply the Montgomery–Taylor lower bound for distinct zeros, in both intervals. Their library also proves that RH places every counted zero on the line. The separate RH release discharges that premise. The rational comparison rounds the known constant down. The contribution here is a reproducible composition of the two formal developments. Earlier work already gave stronger cumulative bounds under RH. [Alpöge–Furman, Theorem A](https://arxiv.org/html/2608.13637v2) · [Chirre, Gonçalves and de Laat, Corollary 3](https://arxiv.org/abs/1810.08843) · [RH announcement](https://alpo.ge/remark.pdf)

`DistinctBound.lean` retains the numerical enclosure adapted from typh's five-point-pyramid proof, which credits Samuel Lavery. The source header records the adaptations. The Apache 2.0 license accompanies this package. [Original enclosure](https://github.com/josusanmartin/riemann/blob/main/submissions/five-point-pyramid/proof/Solution.lean)

## Reproduce

Start with the pinned RH repository and a built or cache-restored checkout including Mathlib. Its README describes installation with Elan and the public build cache. This package expects the checkout's normal `.lake/packages` and `.lake/build/lib/lean` directories. The upstream checkout and its dependencies require substantial disk space. [RH repository and cache instructions](https://github.com/leanprover-community/riemann-hypothesis/tree/2f097b744a6460c73f3e4cc550baa83698409876)

```sh
bash verify.sh /absolute/path/to/built/riemann-hypothesis
```

The script rebuilds the required Zeta23 modules from the original Lean source using the RH release's compiler and Mathlib. It compiles the rational enclosure and both final theorems, checks their axiom lists, and prints the location of the build and audit log. The verifier requires Git, curl, Python 3, tar and Bash.

- Lean 4.33.1, compiler commit `819816b2e0a3bf405af45ae5c7af2491d8f5bee6`.
- Mathlib commit `0df444a360eaa60ab8c11dca51a86af692955474`.
- Zeta23 commit `3635e74826a4c1fcece7d1cd2b6fa75e43a00510`. The dependency pin and toolchain change for the build. The Zeta23 theorem sources compile as published.
- RH repository commit `2f097b744a6460c73f3e4cc550baa83698409876`, source tree `24df20b62d9976ccd20da819bc20b16f808f0fdd`.

## Verification scope

The local run rebuilt the required Zeta23 modules and compiled the new declarations against hash-checked published RH artifacts. Lean’s `leanchecker` also replayed the declarations introduced by each of the two new modules against its imports. Both replay processes exited successfully. The packaged script reproduced the three axiom reports from a second clean Zeta23 source checkout. The compiler output and replay results are in `verification.txt`. Checking the underlying RH development independently from scratch is a separate computation. Sutherland documents independent checks of the RH release, including independent-kernel results, on his verification page. The leaderboard pins a different Mathlib and toolchain and does not provide the RH module used here. [Independent RH checks](https://math.mit.edu/~drew/grh/) · [Leaderboard contract](https://www.riemannzeta.fun/challenge)
