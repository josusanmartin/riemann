#!/usr/bin/env bash
# Use the RH release's compiler and built proof tree to check the corollaries.
set -euo pipefail
if [[ $# != 1 ]]; then
  echo "Usage: bash verify.sh /path/to/built/riemann-hypothesis" >&2
  exit 2
fi
here=$(cd "$(dirname "$0")" && pwd)
rh=$(cd "$1" && pwd)
pin=3635e74826a4c1fcece7d1cd2b6fa75e43a00510
mathlib=0df444a360eaa60ab8c11dca51a86af692955474
[[ $(git -C "$rh" rev-parse HEAD:src) == 24df20b62d9976ccd20da819bc20b16f808f0fdd ]]
[[ $(git -C "$rh/.lake/packages/mathlib" rev-parse HEAD) == "$mathlib" ]]
[[ -f "$rh/.lake/build/lib/lean/Main.olean" ]]
toolbin="$(cd "$rh" && lean --print-prefix)/bin"
[[ $("$toolbin/lean" --version) == *"version 4.33.1,"* ]]
export PATH="$toolbin:$PATH"
work=$(mktemp -d "${TMPDIR:-/tmp}/critical-line-669.XXXXXXXX")
echo "Building in $work"
cd "$work"
curl -fsSL --retry 3 "https://codeload.github.com/anthropics/formal-math/tar.gz/$pin" | tar -xz
cd "formal-math-$pin"
cp "$rh/lean-toolchain" "$rh/lake-manifest.json" .
python3 - "$mathlib" <<'PY'
import sys
from pathlib import Path
file = Path("lakefile.toml")
old = "51e6992efd06126df61a496bebf8f49482a4e129"
source = file.read_text()
assert source.count(old) == 1
file.write_text(source.replace(old, sys.argv[1]))
PY
mkdir -p .lake
ln -s "$rh/.lake/packages" .lake/packages
lake build +Zeta23.ThmD.Mult:olean
cp "$here/DistinctBound.lean" "$here/CriticalLine669.lean" .
lib="$PWD/.lake/build/lib/lean"
lake env lean -o "$lib/DistinctBound.olean" DistinctBound.lean
sp=$(lake env printenv LEAN_PATH)
export LEAN_PATH="$lib:$rh/.lake/build/lib/lean:$sp"
lean -j1 --tstack=400000 -o "$lib/CriticalLine669.olean" CriticalLine669.lean | tee "$work/axioms.log"
python3 - "$work/axioms.log" <<'PY'
import re, sys
from pathlib import Path
log = Path(sys.argv[1]).read_text()
for theorem in ("offLineLoss", "dyadic_669", "cumulative_669"):
    pattern = rf"'CriticalLine669\.{theorem}' depends on axioms: \[([^\]]*)\]"
    found = re.search(pattern, log)
    assert found and set(found[1].split(", ")) == {"propext", "Classical.choice", "Quot.sound"}, theorem
PY
echo "Verified. Build products and audit log are in $work"
