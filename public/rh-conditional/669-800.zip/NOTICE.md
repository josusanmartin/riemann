# Attribution

The numerical Taylor enclosure code in `MontgomeryTaylorRational.lean` and
`ConditionalCandidate.lean` is adapted from the `five-point-pyramid`
submission by typh, which credits Samuel Lavery's `attempt-002` development.
The source is distributed under Apache-2.0; the license is included in
`LICENSE-APACHE-2.0.txt`. The changes and provenance are described in the
source headers.

Source:
https://github.com/josusanmartin/riemann/blob/main/submissions/five-point-pyramid/proof/Solution.lean

The imported Zeta23 mathematics is by the authors credited in the
Alpöge–Furman paper and the Anthropic formalization. It is not reproduced as
a new mathematical discovery in this package.

The cubic extension is reconstructed from Alpöge–Furman's §7.3, using the
published analytic results cited in `research/cubic-derivation.md`. The
interval arithmetic program here is a reproduction of its numerical
constant, not a new RH proof.
