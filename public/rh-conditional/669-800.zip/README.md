# Conditional 669/800 replay on Boat

The two counting statements each take an explicit proof of `RiemannHypothesis`. The third statement compares the exact fractions. Comparator checks these three statements against the attached solution. This is a research replay with a conditional contract. The competitive site's two counting statements require unconditional proofs.

The challenge file preserves the generated template comments and the reference-side `sorry` placeholders. Read the theorem binders for the exact statements. The solution side uses the proof checked by the kernels.

## Reproduce

Use the Zeta23 source tree at commit `3635e74826a4c1fcece7d1cd2b6fa75e43a00510`, its pinned Mathlib and Lean 4.33.0-rc2. Copy the contents of this bundle's `comparator/` into the upstream tree's `comparator/` directory. The website verifier tool pins and isolation scripts are in the site repository at commit `20ec55debc52cf62bef2af24daa781387d64e009`.

After building the pinned libraries and tools, run the site's sandboxed Comparator wrapper from the root of Zeta23 with `comparator/boat-conditional.json` as its config. The wrapper expects the same network-isolated systemd unit and tool environment used by the site's verifier tests. The run log records the actual outcome on Boat.
